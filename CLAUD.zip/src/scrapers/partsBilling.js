// ============================================================
//  PARTS BILLING — Siebel DMS automation (P20 parts billing id)
//  Helmet/part ka bill KAATNE ka pehla hissa:
//    + New order -> Invoice Type Cash -> Contact (mobile se pick)
//    -> drilldown order -> Line Items: + part, qty
//    -> Additional Discount% 99.9 -> Price All -> Fulfill All -> RUK
//  (bill generate/print NAHI — staff review karega)
//
//  DHYAN: Siebel ke element id (s_1_1_30_0_Ctrl…) har session badalte hain,
//  isliye sab STABLE cheez se pakda hai: aria-label / title / button text /
//  field label. Phir bhi Siebel async hai — jahaan atke, console log dekho
//  ki aakhri "[bill] ✓ <step>" kaunsa tha, wahi step tune karna hai.
//
//  Call: await billParts(page, { mobile, lines:[{partNo, qty}], discountPct })
//    page = DMS pe already-logged-in Puppeteer page (scrapeVSR jaisa)
// ============================================================
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();

// ---- Siebel "busy" khatam hone ka intezaar (spinner / overlay) ----
async function settle(page, label = '', max = 40) {
  await sleep(500);
  for (let i = 0; i < max; i++) {
    const busy = await page.evaluate(() => {
      const sel = '.siebui-busy, .siebui-overlay, .siebui-modal-loading, #_overlay, .siebui-spinner, .ui-widget-overlay';
      const b = document.querySelector(sel);
      return !!(b && b.offsetParent !== null);
    }).catch(() => false);
    if (!busy) { await sleep(400); return; }
    await sleep(300);
  }
  if (label) console.log(`  [bill] (settle timeout: ${label})`);
}

// ---- click: aria-label ya title regex se (button/a/span/td/div) ----
async function clickByLabel(page, re, tag) {
  const src = re.source || String(re);
  const hit = await page.evaluate((reSrc) => {
    const rx = new RegExp(reSrc, 'i');
    const els = [...document.querySelectorAll('button,a,span,div,td,[role="button"],li')]
      .filter((e) => e.offsetParent !== null);
    const g = (e) => (e.getAttribute('aria-label') || '') + '|' + (e.getAttribute('title') || '');
    const el = els.find((e) => rx.test(g(e)));
    if (el) { (el.closest('button,a,[role="button"],td,li') || el).click(); return g(el); }
    return null;
  }, src);
  if (hit) { console.log(`  [bill] ✓ click[${tag}] -> ${hit}`); return true; }
  console.log(`  [bill] ✗ click[${tag}] nahi mila (aria/title ~ ${src})`);
  return false;
}

// ---- click: class se (icon buttons), nth-th visible ----
async function clickByClass(page, cls, tag, nth = 0) {
  const hit = await page.evaluate((c, n) => {
    const els = [...document.querySelectorAll('.' + c)].filter((e) => e.offsetParent !== null);
    const el = els[n];
    if (el) { (el.closest('button,a,[role="button"]') || el).click(); return true; }
    return false;
  }, cls, nth);
  console.log(`  [bill] ${hit ? '✓' : '✗'} click[${tag}] .${cls}[${nth}]`);
  return hit;
}

// ---- click: dikhne wale text se (tab/button) ----
async function clickByText(page, text, tag) {
  const hit = await page.evaluate((t) => {
    const want = t.toLowerCase().replace(/\s+/g, ' ').trim();
    const els = [...document.querySelectorAll('a,button,span,div,li,td')].filter((e) => e.offsetParent !== null);
    const el = els.find((e) => (e.textContent || '').toLowerCase().replace(/\s+/g, ' ').trim() === want);
    if (el) { (el.closest('button,a,[role="button"],li,td') || el).click(); return true; }
    const el2 = els.find((e) => (e.textContent || '').toLowerCase().replace(/\s+/g, ' ').trim().includes(want) && (e.textContent || '').length < want.length + 25);
    if (el2) { (el2.closest('button,a,[role="button"],li,td') || el2).click(); return true; }
    return null;
  }, text);
  console.log(`  [bill] ${hit ? '✓' : '✗'} click[${tag}] text="${text}"`);
  return !!hit;
}

// ---- form field me type karo (label ke aria-label se input dhoondo) ----
async function typeField(page, labelRe, value, tag) {
  const src = labelRe.source || String(labelRe);
  const ok = await page.evaluate((reSrc, val) => {
    const rx = new RegExp(reSrc, 'i');
    const ins = [...document.querySelectorAll('input,textarea')].filter((e) => e.offsetParent !== null);
    const el = ins.find((e) => rx.test(e.getAttribute('aria-label') || '') || rx.test(e.getAttribute('name') || '') || rx.test(e.getAttribute('title') || ''));
    if (!el) return false;
    el.focus(); el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }, src, value);
  if (!ok) { console.log(`  [bill] ✗ field[${tag}] nahi mila (~${src})`); return false; }
  await page.keyboard.type(String(value), { delay: 40 });
  await page.keyboard.press('Tab');
  console.log(`  [bill] ✓ field[${tag}] = ${value}`);
  return true;
}

// ---- Siebel combo (Invoice Type jaisa): label ke paas dropdown khol ke option chuno ----
async function pickCombo(page, labelText, optionText, tag) {
  // dropdown arrow kholo — field ke row me siebui-icon-dropdown
  const opened = await page.evaluate((lbl) => {
    const want = lbl.toLowerCase();
    // field ka container dhoondo jisme label text ho
    const labels = [...document.querySelectorAll('td,span,div,label')].filter((e) => e.offsetParent !== null && (e.textContent || '').toLowerCase().replace(/\s+/g, ' ').trim().startsWith(want));
    for (const L of labels) {
      const row = L.closest('tr, .siebui-collapsible-cont, div');
      const dd = row && row.querySelector('.siebui-icon-dropdown, .applet-form-combo');
      if (dd && dd.offsetParent !== null) { dd.click(); return true; }
    }
    // fallback: koi bhi visible combo
    return false;
  }, labelText);
  if (!opened) { console.log(`  [bill] ✗ combo[${tag}] dropdown nahi khula (${labelText})`); return false; }
  await sleep(700);
  const picked = await page.evaluate((opt) => {
    const want = opt.toLowerCase().replace(/\s+/g, ' ').trim();
    const items = [...document.querySelectorAll('.ui-menu-item-wrapper, .ui-menu-item, li[role="option"], .ui-autocomplete li')].filter((e) => e.offsetParent !== null);
    const el = items.find((e) => (e.textContent || '').toLowerCase().replace(/\s+/g, ' ').trim() === want);
    if (el) { el.click(); return true; }
    return false;
  }, optionText);
  console.log(`  [bill] ${picked ? '✓' : '✗'} combo[${tag}] ${labelText} = ${optionText}`);
  return picked;
}

// ---- Contact ko MOBILE se pick karo (pick dialog) ----
async function pickContactByMobile(page, mobile) {
  // form me contact pick icon (siebui-icon-pick) kholo
  await clickByClass(page, 'siebui-icon-pick', 'contact-pick', 0);
  await settle(page, 'pick-dialog');
  await sleep(1200);
  // pick dialog me query field me mobile daalo
  const typed = await page.evaluate((mob) => {
    const dlg = document.querySelector('.ui-dialog:not([style*="display: none"]), .siebui-popup-applet, [id*="Pick"]');
    const scope = dlg || document;
    const ins = [...scope.querySelectorAll('input')].filter((e) => e.offsetParent !== null);
    // mobile wala query input — aksar sabse upar / "Mobile" aria
    const el = ins.find((e) => /mobile|phone/i.test((e.getAttribute('aria-label') || '') + (e.getAttribute('name') || ''))) || ins[1] || ins[0];
    if (!el) return false;
    el.focus(); el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    window.__pickInput = true;
    return true;
  }, mobile);
  if (typed) { await page.keyboard.type(String(mobile), { delay: 50 }); await page.keyboard.press('Enter'); }
  await settle(page, 'pick-query');
  await sleep(1200);
  // pehli matching row select karo (mobile match)
  const rowOk = await page.evaluate((mob) => {
    const m = String(mob).replace(/\D/g, '');
    const cells = [...document.querySelectorAll('td,div[role="gridcell"]')].filter((e) => e.offsetParent !== null);
    const c = cells.find((e) => (e.textContent || '').replace(/\D/g, '').includes(m) && m.length >= 7);
    if (c) { const tr = c.closest('tr'); (tr || c).click(); return true; }
    // warna pehli data row
    const firstRow = document.querySelector('.ui-dialog tr[id*="_r_"], .siebui-popup-applet tr');
    if (firstRow) { firstRow.click(); return true; }
    return false;
  }, mobile);
  console.log(`  [bill] ${rowOk ? '✓' : '✗'} contact row select (mobile ${mobile})`);
  await sleep(500);
  // OK dabao
  const ok = await clickByLabel(page, /Pick Contact List:OK|:OK$/, 'pick-OK') || await clickByText(page, 'OK', 'pick-OK2');
  await settle(page, 'after-pick');
  return ok;
}

// ---- order number drilldown (temp order) pe click ----
async function openOrderDrilldown(page) {
  const ok = await page.evaluate(() => {
    const a = [...document.querySelectorAll('a.drilldown, td[id*="Order_Number"] a, td[id*="_l_Order_Number"] a')].filter((e) => e.offsetParent !== null)[0];
    if (a) { a.click(); return a.textContent.trim(); }
    return null;
  });
  console.log(`  [bill] ${ok ? '✓' : '✗'} drilldown order -> ${ok || ''}`);
  return !!ok;
}

// ---- Line Items grid me ek part add karo ----
async function addLineItem(page, partNo, qty) {
  // Line Items applet ka "+" (newrecord). Agar 2 applet hain to pehla line-items wala.
  // header "Line Items" wale applet ka newrecord dhoondo
  const added = await page.evaluate(() => {
    const heads = [...document.querySelectorAll('*')].filter((e) => e.offsetParent !== null && norm(e.textContent) === 'Line Items');
    function norm(s){ return String(s||'').replace(/\s+/g,' ').trim(); }
    let applet = null;
    for (const h of heads) { const a = h.closest('.siebui-applet, [id^="s_"], div'); if (a && a.querySelector('.siebui-icon-newrecord')) { applet = a; break; } }
    const btn = (applet || document).querySelector('.siebui-icon-newrecord');
    if (btn && btn.offsetParent !== null) { (btn.closest('button,a') || btn).click(); return true; }
    return false;
  });
  console.log(`  [bill] ${added ? '✓' : '✗'} Line Items + (new row)`);
  await settle(page, 'line-new');
  await sleep(800);
  // Part # cell me type (naye row ka part field)
  const pt = await page.evaluate(() => {
    const ins = [...document.querySelectorAll('input')].filter((e) => e.offsetParent !== null);
    const el = ins.find((e) => /part\s*#|part\s*number|part_no|part no/i.test((e.getAttribute('aria-label') || '') + (e.getAttribute('name') || '')));
    if (el) { el.focus(); el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); return true; }
    return false;
  });
  if (pt) { await page.keyboard.type(String(partNo), { delay: 45 }); await page.keyboard.press('Tab'); }
  console.log(`  [bill] ${pt ? '✓' : '✗'} Part # = ${partNo}`);
  await settle(page, 'part-set');
  await sleep(900);
  // Qty cell
  const qok = await page.evaluate(() => {
    const ins = [...document.querySelectorAll('input')].filter((e) => e.offsetParent !== null);
    const el = ins.find((e) => /order\s*qty|issue|quantity|order_qty/i.test((e.getAttribute('aria-label') || '') + (e.getAttribute('name') || '')));
    if (el) { el.focus(); el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); return true; }
    return false;
  });
  if (qok) { await page.keyboard.type(String(qty), { delay: 45 }); await page.keyboard.press('Tab'); }
  console.log(`  [bill] ${qok ? '✓' : '✗'} Qty = ${qty}`);
  await settle(page, 'qty-set');
  return pt;
}

// ============================================================
//  MAIN
// ============================================================
async function billParts(page, opts = {}) {
  const { mobile, lines = [], discountPct } = opts;
  console.log('[bill] START', JSON.stringify(opts));

  // 1) + New Order (Counter Sale Orders applet ka newrecord — sabse upar wala)
  await settle(page, 'view-load');
  await clickByClass(page, 'siebui-icon-newrecord', 'new-order', 0);
  await settle(page, 'order-new');
  await sleep(900);

  // 2) Invoice Type = Cash
  await pickCombo(page, 'Invoice Type', 'Cash', 'invoice-type');
  await settle(page, 'cash-set');

  // 3) Contact mobile se pick
  if (mobile) await pickContactByMobile(page, mobile);

  // 4) order number drilldown -> Line Item Actions
  await sleep(600);
  await openOrderDrilldown(page);
  await settle(page, 'line-actions');
  await sleep(1000);

  // 5) Line Items Details tab -> parts add
  await clickByText(page, 'Line Items Details', 'tab-lines');
  await settle(page, 'tab-lines');
  await sleep(700);
  for (const ln of lines) await addLineItem(page, ln.partNo, ln.qty);

  // 6) Additional Discount% (item ke baad) — Sales Order tab pe header field
  if (discountPct != null && discountPct !== '') {
    await clickByText(page, 'Sales Order', 'tab-order');
    await settle(page, 'tab-order');
    await sleep(600);
    await typeField(page, /additional\s*discount/i, discountPct, 'add-disc');
    await settle(page, 'disc-set');
    await clickByText(page, 'Line Items Details', 'tab-lines2');
    await settle(page, 'tab-lines2');
    await sleep(600);
  }

  // 7) Price All -> Fulfill All
  await (clickByLabel(page, /Price All/, 'price-all') );
  await settle(page, 'price-all');
  await sleep(900);
  await (clickByText(page, 'Fulfill All', 'fulfill-all') || clickByLabel(page, /Fulfill All/, 'fulfill-all2'));
  await settle(page, 'fulfill-all');

  console.log('[bill] DONE (ruk gaye — ab staff review kare; bill generate/print NAHI kiya)');
  return { ok: true };
}

module.exports = { billParts };